import Funcons.Tools (mkMainWithLibraryEntitiesTypes)
import Funcons.Golang.Library
main = mkMainWithLibraryEntitiesTypes funcons entities types